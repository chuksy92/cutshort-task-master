

declare interface ErrorConstructor {
  captureStackTrace(targetObject: Object, constructorOpt?: Function): void;
}
